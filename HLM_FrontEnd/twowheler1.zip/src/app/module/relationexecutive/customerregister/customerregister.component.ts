import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
